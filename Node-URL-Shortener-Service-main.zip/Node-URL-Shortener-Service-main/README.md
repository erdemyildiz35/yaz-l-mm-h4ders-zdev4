# Node-URL-Shortener-Service
A URL shortener service like bit.ly
## Run
npm install
## npm run devStart
